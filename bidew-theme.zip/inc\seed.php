<?php
/* Contenu initial (une seule fois, à l'activation) : pages, chapitres d'histoire, albums, vidéos, membres, engagements.
   Source : data/content.json. Rien n'est marqué « vérifié » : à confirmer par le groupe. */
if (!defined('ABSPATH')) exit;

function bidew_seed() {
    if (get_option('bidew_seed_v2')) return;
    $d = bidew_data();

    foreach ($d['chapters'] as $i => $c) {
        $id = wp_insert_post(['post_type' => 'jalon', 'post_status' => 'publish', 'post_title' => $c['title'], 'post_content' => $c['html'], 'menu_order' => $i]);
        if (!$id) continue;
        update_post_meta($id, 'annee', $c['year']); update_post_meta($id, 'kicker', $c['kicker']);
        update_post_meta($id, 'sources', implode("\n", array_map(fn($s) => $s[0] . '|' . $s[1], $c['sources'])));
    }
    foreach ($d['albums'] as $i => $a) {
        $id = wp_insert_post(['post_type' => 'album', 'post_status' => 'publish', 'post_title' => $a['title'], 'post_content' => $a['note'], 'menu_order' => $i]);
        if (!$id) continue;
        update_post_meta($id, 'annee', $a['year']);
        if ($a['yt']) update_post_meta($id, 'lien_ecoute', bidew_watch($a['yt']));
        if (!empty($a['cover'])) update_post_meta($id, 'cover', $a['cover']);
        if (!empty($a['links'])) update_post_meta($id, 'liens', implode("\n", array_map(fn($l) => $l[0] . '|' . $l[1], $a['links'])));
        if ($a['tracks']) update_post_meta($id, 'pistes', implode("\n", array_map(fn($t) => $t[0] . '|' . $t[1], $a['tracks'])));
    }
    foreach ($d['videos'] as $i => [$titre, $vid]) {
        $id = wp_insert_post(['post_type' => 'video', 'post_status' => 'publish', 'post_title' => $titre, 'menu_order' => $i]);
        if ($id) update_post_meta($id, 'url_video', bidew_watch($vid));
    }
    foreach ($d['members'] as $i => $m) {
        $id = wp_insert_post(['post_type' => 'membre', 'post_status' => 'publish', 'post_title' => $m['name'], 'post_content' => $m['bio'], 'menu_order' => $i]);
        if ($id) update_post_meta($id, 'role', $m['role']);
    }
    foreach ($d['engagements'] as $i => $e) {
        $id = wp_insert_post(['post_type' => 'engagement', 'post_status' => 'publish', 'post_title' => $e['title'], 'post_content' => $e['text'], 'menu_order' => $i]);
        if ($id && !empty($e['img'])) update_post_meta($id, 'img', $e['img']);
    }

    /* Pages : accueil statique + une page par section (la page « actualites » affiche les articles) */
    $home = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Accueil', 'post_name' => 'accueil']);
    $posts = 0;
    foreach ($d['nav'] as $n) {
        $pid = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $n['title'], 'post_name' => $n['slug']]);
        if ($n['slug'] === 'actualites') $posts = $pid;
    }
    wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Mentions légales', 'post_name' => 'mentions-legales']);
    if ($home) { update_option('show_on_front', 'page'); update_option('page_on_front', $home); }
    if ($posts) update_option('page_for_posts', $posts);
    update_option('permalink_structure', '/%postname%/'); flush_rewrite_rules();

    update_option('bidew_youtube', 'https://www.youtube.com/@bideew_boubess');
    update_option('bidew_seed_v2', 1);
}
add_action('after_switch_theme', 'bidew_seed');
