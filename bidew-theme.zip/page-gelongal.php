<?php get_header();
bidew_page_hero('gelongal', 'Gelongal', '× Bideew Bou Bess', bidew_data()['gelongal']['intro']); ?>
<section class="sec"><?php bidew_render_gelongal('stats'); ?></section>
<section class="sec white"><?php bidew_head('Qui est Gelongal ?', 'Un collectif de trois frères, entre musique, cinéma et arts visuels.', 'Le collectif'); bidew_render_gelongal('who'); ?></section>
<section class="sec"><?php bidew_head('Quinze ans de clips ensemble', 'Les vidéos de Bideew Bou Bess réalisées par Gelongal, avec leurs dates et leur audience.', 'La collaboration'); bidew_render_gelongal('collab'); ?></section>
<section class="sec dark"><?php bidew_head('Hommage à Bathie', 'Un album-prière pour un frère de musique et d\'images.', '1 SAMBA'); bidew_render_gelongal('tribute'); bidew_link_more(home_url('/discographie/'), 'Écouter 1 SAMBA', true); ?></section>
<section class="sec"><?php bidew_head('Sources', 'D\'où viennent ces informations.', 'Références'); bidew_render_gelongal('sources'); ?></section>
<?php bidew_cta('Un clip, une production, une collaboration ?', 'Contacter le groupe', home_url('/contact/'));
get_footer();