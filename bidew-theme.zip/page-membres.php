<?php get_header();
bidew_page_hero('membres', 'Les frères', 'Sall', 'Moctar, Baïdy (Beydi) et Ibrahima (Ibrahim) : trois voix, une même famille.'); ?>
<section class="sec"><?php bidew_render_members(); ?></section>
<?php get_footer();