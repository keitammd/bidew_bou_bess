</main>
<?php if (!is_page(['contact', 'mentions-legales'])) bidew_render_newsband(); ?>
<footer>
  <div class="flag-stripe" aria-hidden="true"></div>
  <div class="cols">
    <div><p class="foot-brand">BIDEEW BOU BESS</p><p style="color:#b7b1a4;max-width:34ch;margin-top:8px">Site officiel du groupe de hip-hop sénégalais. Dalal ak jàmm.</p></div>
    <ul><?php foreach (bidew_nav_items() as $n) printf('<li><a href="%s">%s</a></li>', esc_url($n['url']), esc_html($n['title'])); ?></ul>
    <div class="socials"><?php foreach (bidew_socials() as $label => $url) printf('<a href="%s" target="_blank" rel="noopener me">%s</a>', esc_url($url), esc_html($label)); ?></div>
  </div>
  <p class="legal">© <?php echo esc_html(date('Y')); ?> BIDEEW BOU BESS — Tous droits réservés. · <a href="<?php echo esc_url(home_url('/mentions-legales/')); ?>">Mentions légales</a></p>
</footer>
<button type="button" class="totop" aria-label="Haut de page" hidden>↑</button>
<?php wp_footer(); ?>
</body>
</html>