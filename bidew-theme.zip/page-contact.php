<?php get_header();
bidew_page_hero('contact', 'Booking', '& contact', 'Concerts, festivals, collaborations, presse : écrivez-nous.'); ?>
<section class="sec" id="booking"><?php bidew_head('Écrire au groupe', 'Nous répondons aux demandes de booking, de presse et de collaboration.', 'Contact'); bidew_render_booking(); ?></section>
<section class="sec white" id="concerts"><?php bidew_head('Prochains concerts', 'Les dates du groupe, dès qu\'elles sont annoncées.', 'Scène'); bidew_render_concerts(); ?></section>
<section class="sec" id="newsletter"><?php bidew_head('Restez dans le rythme', 'Recevez les sorties et dates de concerts.', 'Newsletter'); bidew_render_newsletter(); ?></section>
<?php get_footer();
