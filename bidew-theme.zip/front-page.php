<?php get_header(); $u = fn($s) => home_url('/' . $s . '/'); $img = fn($f) => esc_url(get_template_directory_uri() . '/assets/img/' . $f); ?>
<section class="hero-slider" id="accueil" aria-roledescription="carrousel" aria-label="À la une">
  <div class="slide is-active"><img src="<?php echo $img('trio-noir-blanc.jpg'); ?>" alt="Le trio de Bideew Bou Bess en noir et blanc" fetchpriority="high"<?php echo bidew_img_attrs('trio-noir-blanc.jpg'); ?>>
    <div class="slide-text"><p class="kicker">Sénégal · Hip-hop · Depuis 1994</p><h1>Bideew Bou Bess</h1><p class="sub">La nouvelle étoile du hip-hop sénégalais</p><a class="btn" href="<?php echo esc_url($u('discographie')); ?>">Écouter la musique</a></div></div>
  <div class="slide"><img src="<?php echo $img('concert-chant.jpg'); ?>" alt="Un membre du groupe chante sur scène" class="top" loading="lazy">
    <div class="slide-text"><p class="kicker">Sur scène</p><h2>Le live, depuis 1994</h2><p class="sub">Concerts, festivals, tournées</p><a class="btn" href="<?php echo esc_url($u('galerie')); ?>">Voir la galerie</a></div></div>
  <div class="slide"><img src="<?php echo $img('engagement-unhcr.jpg'); ?>" alt="Un membre du groupe en t-shirt Engagé" loading="lazy">
    <div class="slide-text"><p class="kicker">Engagés</p><h2>Plus qu'une musique</h2><p class="sub">Santé, éducation, citoyenneté</p><a class="btn" href="<?php echo esc_url($u('engagements')); ?>">Nos engagements</a></div></div>
  <button class="arrow prev" type="button" aria-label="Diapositive précédente">‹</button><button class="arrow next" type="button" aria-label="Diapositive suivante">›</button>
  <div class="dots"><button type="button" class="on" aria-label="Diapositive 1"></button><button type="button" aria-label="Diapositive 2"></button><button type="button" aria-label="Diapositive 3"></button></div>
</section>

<?php bidew_render_ticker(); bidew_render_headline(); ?>
<section class="sec" id="a-la-une">
  <?php bidew_head('Dernières actualités', 'Sorties, clips et nouvelles du groupe.', 'À la une'); bidew_render_news(3, 'latest'); bidew_link_more($u('actualites'), 'Toutes les actualités'); ?>
</section>

<section class="feature">
  <img src="<?php echo $img('pirogues-peintes.jpg'); ?>" alt="Pirogues peintes sur la plage" loading="lazy">
  <div class="txt"><p class="eyebrow" style="color:var(--or)">Histoire</p><h2>De Podor aux scènes du monde</h2>
    <p>1994 · 1996 · 1999 · 2003 · 2010 · 2025. Trois frères, un concours, des albums, des tournées : le récit complet, sourcé, chapitre après chapitre.</p>
    <div><a class="btn primary" href="<?php echo esc_url($u('histoire')); ?>">Lire l'histoire</a></div></div>
</section>

<section class="sec white" id="ecouter">
  <?php bidew_head('Écouter partout', 'Spotify, Apple Music, Deezer, YouTube : les profils officiels du groupe.', 'Plateformes'); bidew_render_platforms(false); ?>
  <div style="margin-top:44px"><?php bidew_render_stats(); ?></div>
</section>

<section class="sec" id="discographie">
  <?php bidew_head('Discographie', 'Quatre albums, des singles et des collaborations.', 'Musique'); bidew_render_albums(false); bidew_link_more($u('discographie'), 'Toute la discographie'); ?>
</section>

<section class="sec white" id="concerts">
  <?php bidew_head('Prochains concerts', 'Les dates du groupe, dès qu\'elles sont annoncées.', 'Scène'); bidew_render_concerts(); ?>
</section>

<section class="sec dark" id="videos">
  <?php bidew_head('Vidéos', 'Les clips officiels du groupe.', 'Images'); bidew_render_videos(3); bidew_link_more($u('videos'), 'Toutes les vidéos'); ?>
</section>

<section class="sec dark" id="galerie">
  <?php bidew_head('Galerie', 'Concerts, engagements, portraits et Sénégal en images.', 'Photos'); bidew_render_gallery(6); bidew_link_more($u('galerie'), 'Voir toutes les photos'); ?>
</section>

<section class="sec" id="membres">
  <?php bidew_head('Les frères', 'Moctar, Beydi et Ibrahim Sall.', 'Famille'); bidew_render_members(); ?>
</section>

<section class="feature">
  <img src="<?php echo $img('concert-guitare.jpg'); ?>" alt="" loading="lazy">
  <div class="txt"><p class="eyebrow" style="color:var(--or)">Collaboration</p><h2>Gelongal × Bideew Bou Bess</h2>
    <p>Neuf clips, plus de 17 millions de vues et un album-hommage : l'histoire du collectif frère qui met le groupe en images depuis 2011.</p>
    <div><a class="btn primary" href="<?php echo esc_url($u('gelongal')); ?>">Découvrir la collaboration</a></div></div>
</section>

<section class="sec dark" id="partenaires">
  <?php bidew_head('Partenaires', 'Labels, artistes, institutions et ONG aux côtés du groupe.', 'Alliés'); bidew_render_partners(true); bidew_link_more($u('partenaires'), 'Tous les partenaires'); ?>
</section>

<section class="cta-band">
  <div class="reveal"><h2>Un concert, un festival, une collaboration ?</h2><a class="btn primary" href="<?php echo esc_url($u('contact')); ?>">Contacter le groupe</a></div>
</section>
<?php get_footer();