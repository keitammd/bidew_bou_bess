<?php get_header();
bidew_page_hero('engagements', 'Engagements', 'et valeurs', 'Éducation, santé, terre et citoyenneté : le groupe agit au-delà de la scène.'); ?>
<section class="sec"><?php bidew_render_engagements(); ?><p class="note">Informations issues de la fiche WOMEX ; à valider avec le groupe et ses partenaires avant publication définitive.</p></section>
<?php get_footer();