<?php get_header();
bidew_page_hero('mentions-legales', 'Mentions', 'légales', 'Mentions légales, confidentialité et gestion des données.'); ?>
<section class="sec prose"><?php bidew_render_legal(); ?><p class="note">Page type à faire valider et compléter (éditeur, hébergeur, crédits) avant la mise en ligne.</p></section>
<?php get_footer();