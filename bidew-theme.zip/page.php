<?php get_header(); while (have_posts()) : the_post(); ?>
<article class="page-body" style="padding:160px var(--gutter) 100px;max-width:860px;margin:auto">
  <p class="eyebrow"><?php echo esc_html(get_the_date()); ?></p>
  <h1 style="font-family:var(--serif);font-size:clamp(2.2rem,6vw,4rem);line-height:1.05;margin-bottom:30px"><?php the_title(); ?></h1>
  <?php if (has_post_thumbnail()) the_post_thumbnail('large'); ?>
  <div class="entry"><?php the_content(); ?></div>
</article>
<?php endwhile; get_footer();
