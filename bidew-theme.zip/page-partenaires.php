<?php get_header();
bidew_page_hero('partenaires', 'Partenaires', 'et alliés', 'Labels, artistes, institutions et ONG qui ont jalonné le parcours de Bideew Bou Bess.'); ?>
<section class="sec"><?php bidew_render_partners(); ?><p class="note">Les logos des partenaires ne sont pas utilisés sans leur accord. Chaque lien renvoie vers une source publique ; les partenariats seront validés avec le groupe avant publication définitive.</p></section>
<?php bidew_cta('Devenir partenaire du groupe', 'Nous contacter', home_url('/contact/'));
get_footer();