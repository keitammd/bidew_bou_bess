<?php
/* SEO, réseaux sociaux, newsletter, performance */
if (!defined('ABSPATH')) exit;

function bidew_social_fields() {
    return [
        'bidew_youtube' => 'YouTube', 'bidew_facebook' => 'Facebook', 'bidew_instagram' => 'Instagram',
        'bidew_tiktok' => 'TikTok', 'bidew_spotify' => 'Spotify', 'bidew_presskit' => 'Dossier de presse (URL du PDF)',
        'bidew_og_image' => 'Image de partage (URL)',
    ];
}

add_action('admin_init', function () {
    foreach (bidew_social_fields() as $opt => $label) {
        register_setting('general', $opt, ['type' => 'string', 'sanitize_callback' => 'esc_url_raw']);
        add_settings_field($opt, $label, function () use ($opt) {
            printf('<input type="url" class="regular-text" name="%s" value="%s">', esc_attr($opt), esc_attr(get_option($opt)));
        }, 'general');
    }
});

function bidew_socials() {
    $out = [];
    foreach (bidew_social_fields() as $opt => $label) {
        if (in_array($opt, ['bidew_presskit', 'bidew_og_image'], true)) continue;
        if ($u = get_option($opt)) $out[$label] = $u;
    }
    if (empty($out['Instagram'])) $out['Instagram'] = bidew_data()['site']['instagram'];
    return $out;
}

/* Slug de la page courante (clé de data/content.json → pages_meta) */
function bidew_current_slug() {
    if (is_front_page()) return 'index';
    if (is_home()) return 'actualites';
    return is_page() ? get_post_field('post_name', get_queried_object_id()) : '';
}

/* Titre : « Titre de page | BIDEEW BOU BESS » */
add_filter('document_title_separator', fn() => '|');
add_filter('document_title_parts', function ($p) {
    $m = bidew_page_meta(bidew_current_slug());
    if ($m[0]) { $p['title'] = $m[0]; unset($p['page'], $p['tagline']); }
    $p['site'] = 'BIDEEW BOU BESS';
    return $p;
});

/* Balises SEO / Open Graph / Twitter / icônes / polices préchargées */
add_action('wp_head', function () {
    $m = bidew_page_meta(bidew_current_slug());
    $desc = $m[1] ?: 'Site officiel de BIDEEW BOU BESS, groupe de hip-hop sénégalais.';
    if (is_singular('post')) { $d = wp_strip_all_tags(get_the_excerpt()); if ($d) $desc = $d; }
    $img = get_option('bidew_og_image') ?: bidew_img(bidew_data()['site']['og']);
    if (is_singular('post') && has_post_thumbnail()) $img = get_the_post_thumbnail_url(null, 'large');
    $url = is_singular() ? get_permalink() : (is_home() && get_option('page_for_posts') ? get_permalink(get_option('page_for_posts')) : home_url('/'));
    echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n" . '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
    foreach (['og:title' => wp_get_document_title(), 'og:description' => $desc, 'og:type' => is_singular('post') ? 'article' : 'website', 'og:url' => $url, 'og:image' => $img, 'og:locale' => 'fr_FR', 'og:site_name' => 'BIDEEW BOU BESS'] as $k => $v)
        echo '<meta property="' . $k . '" content="' . esc_attr($v) . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url(bidew_img('favicon-32.png')) . '"><link rel="apple-touch-icon" href="' . esc_url(bidew_img('apple-touch-icon.png')) . '">' . "\n";
    foreach (['oswald', 'inter'] as $f) echo '<link rel="preload" href="' . esc_url(get_template_directory_uri() . "/assets/fonts/$f.woff2") . '" as="font" type="font/woff2" crossorigin>' . "\n";
}, 1);

/* Mesure d'audience sans cookie (Plausible) : active seulement si un domaine est renseigné */
add_action('wp_head', function () {
    if ($d = get_option('bidew_analytics_domain')) printf('<script defer data-domain="%s" src="https://plausible.io/js/script.js"></script>' . "\n", esc_attr($d));
}, 5);

/* Données structurées : groupe, albums, concerts à venir */
add_action('wp_head', function () {
    if (!is_front_page()) return;
    $d = bidew_data(); $albums = []; $events = [];
    foreach (get_posts(['post_type' => 'album', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']) as $a) $albums[] = ['@type' => 'MusicAlbum', 'name' => get_the_title($a)];
    foreach (bidew_upcoming_concerts() as $c) if ($c['date']) $events[] = ['@type' => 'MusicEvent', 'name' => 'Bideew Bou Bess — ' . ($c['ville'] ?: $c['title']), 'startDate' => $c['date'],
        'location' => ['@type' => 'Place', 'name' => $c['lieu'] ?: $c['ville'], 'address' => $c['ville']], 'performer' => ['@type' => 'MusicGroup', 'name' => 'BIDEEW BOU BESS'], 'url' => $c['billet'] ?: home_url('/')];
    $same = array_merge(array_values(bidew_socials()), array_column($d['platforms'], 1), array_column(array_slice($d['references'], 0, 4), 1));
    $graph = [['@type' => 'MusicGroup', 'name' => 'BIDEEW BOU BESS', 'alternateName' => 'Bideew Bou Bess', 'genre' => ['Hip-hop', 'Afro-rap'], 'foundingDate' => '1994',
        'foundingLocation' => ['@type' => 'Country', 'name' => 'Sénégal'], 'description' => bidew_page_meta('index')[1], 'image' => bidew_img($d['site']['og']), 'url' => home_url('/'), 'sameAs' => array_values(array_unique($same)), 'album' => $albums],
        ['@type' => 'WebSite', 'name' => 'BIDEEW BOU BESS', 'url' => home_url('/'), 'inLanguage' => 'fr']];
    echo '<script type="application/ld+json">' . wp_json_encode(['@context' => 'https://schema.org', '@graph' => array_merge($graph, $events)], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}, 2);

/* Performance : retire les scripts inutiles */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
add_filter('wp_resource_hints', function ($urls, $rel) {
    if ($rel === 'preconnect') $urls[] = 'https://i.ytimg.com';
    return $urls;
}, 10, 2);

/* Newsletter (consentement explicite, stockage privé) */
add_action('init', function () {
    register_post_type('abonne', ['labels' => ['name' => 'Abonnés', 'singular_name' => 'Abonné'], 'public' => false, 'show_ui' => true,
        'menu_icon' => 'dashicons-email-alt', 'supports' => ['title'], 'capability_type' => 'post']);
});

function bidew_handle_newsletter() {
    $back = wp_get_referer() ?: home_url('/');
    $status = 'error';
    if (isset($_POST['bidew_news_nonce']) && wp_verify_nonce($_POST['bidew_news_nonce'], 'bidew_news') && empty($_POST['website'])) {
        $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        if (!is_email($email) || empty($_POST['consent'])) $status = 'invalid';
        elseif (get_posts(['post_type' => 'abonne', 'title' => $email, 'numberposts' => 1, 'fields' => 'ids'])) $status = 'ok';
        elseif (wp_insert_post(['post_type' => 'abonne', 'post_status' => 'publish', 'post_title' => $email])) $status = 'ok';
    }
    wp_safe_redirect(add_query_arg('news', $status, $back) . '#newsletter'); exit;
}
add_action('admin_post_nopriv_bidew_news', 'bidew_handle_newsletter');
add_action('admin_post_bidew_news', 'bidew_handle_newsletter');
