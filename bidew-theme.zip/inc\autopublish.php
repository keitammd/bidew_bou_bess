<?php
/* Publication automatique : nouveaux clips (chaîne YouTube officielle) et sorties musicales (Deezer),
   + flux RSS supplémentaires (réseaux, presse, plateformes) saisis dans Réglages → Général.
   Les réseaux sans flux public (Instagram, TikTok, Facebook, X) ne peuvent pas être lus automatiquement. */
if (!defined('ABSPATH')) exit;

const BIDEEW_DEEZER_ARTIST = '2930481';

/* ---------- Réglages ---------- */
add_action('admin_init', function () {
    register_setting('general', 'bidew_auto_mode', ['type' => 'string', 'sanitize_callback' => fn($v) => in_array($v, ['publish', 'draft', 'off'], true) ? $v : 'publish']);
    add_settings_field('bidew_auto_mode', 'Publication automatique', function () {
        $m = get_option('bidew_auto_mode', 'publish');
        echo '<select name="bidew_auto_mode">';
        foreach (['publish' => 'Publier directement', 'draft' => 'Créer un brouillon à valider', 'off' => 'Désactivée'] as $k => $l) printf('<option value="%s"%s>%s</option>', $k, selected($m, $k, false), esc_html($l));
        echo '</select> <a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=bidew_sync'), 'bidew_sync')) . '">Synchroniser maintenant</a>';
        $last = get_option('bidew_auto_report');
        if ($last) echo '<p class="description">Dernière synchro : ' . esc_html($last) . '. Contrôle toutes les heures : YouTube officiel, Deezer, flux RSS ci-dessous.</p>';
    }, 'general');
    register_setting('general', 'bidew_auto_feeds', ['type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field']);
    add_settings_field('bidew_auto_feeds', 'Flux RSS supplémentaires (un par ligne)', function () {
        printf('<textarea class="large-text" rows="3" name="bidew_auto_feeds" placeholder="https://exemple.com/flux-bideew.xml">%s</textarea><p class="description">Alerte Google (flux RSS) « Bideew Bou Bess », flux d\'un pont RSS Instagram/TikTok/Facebook/X, etc.</p>', esc_textarea(get_option('bidew_auto_feeds')));
    }, 'general');
});

/* ---------- Planification ---------- */
add_action('init', function () {
    if (!wp_next_scheduled('bidew_autosync')) wp_schedule_event(time() + 300, 'hourly', 'bidew_autosync');
});
add_action('bidew_autosync', 'bidew_autosync_run');
add_action('admin_post_bidew_sync', function () {
    if (!current_user_can('manage_options')) wp_die('Accès refusé');
    check_admin_referer('bidew_sync');
    bidew_autosync_run();
    wp_safe_redirect(admin_url('options-general.php')); exit;
});
add_action('switch_theme', fn() => wp_clear_scheduled_hook('bidew_autosync'));

/* ---------- Synchronisation ---------- */
function bidew_remote($url) {
    $r = wp_remote_get($url, ['timeout' => 10, 'user-agent' => 'BideewSite/1.0']);
    return (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) ? wp_remote_retrieve_body($r) : '';
}
function bidew_already($key) {
    return (bool) get_posts(['post_type' => 'post', 'post_status' => 'any', 'meta_key' => '_bidew_src', 'meta_value' => $key, 'numberposts' => 1, 'fields' => 'ids']);
}
function bidew_sideload($url, $post_id) {
    if (!$url) return;
    require_once ABSPATH . 'wp-admin/includes/media.php'; require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/image.php';
    $id = media_sideload_image($url, $post_id, null, 'id');
    if (!is_wp_error($id)) set_post_thumbnail($post_id, $id);
}
function bidew_category($name) {
    $t = term_exists($name, 'category');
    if (!$t) $t = wp_insert_term($name, 'category');
    return is_wp_error($t) ? [] : [(int) (is_array($t) ? $t['term_id'] : $t)];
}

/* Retourne la liste des éléments nouveaux : [key, title, date, content, cat, thumb, link, yt] */
function bidew_collect() {
    $items = [];
    // 1) Chaîne YouTube officielle
    $id = get_option('bidew_yt_channel') ?: bidew_data()['channel']['id'];
    if ($xml = @simplexml_load_string(bidew_remote('https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode($id)) ?: '<x/>')) {
        foreach ($xml->entry as $e) {
            $yt = (string) $e->children('http://www.youtube.com/xml/schemas/2015')->videoId; $t = (string) $e->title;
            if (!$yt) continue;
            $items[] = ['key' => 'yt:' . $yt, 'title' => $t, 'date' => (string) $e->published, 'cat' => 'Nouveau clip', 'thumb' => 'https://i.ytimg.com/vi/' . $yt . '/maxresdefault.jpg', 'link' => bidew_watch($yt), 'yt' => $yt,
                'content' => 'Un nouveau titre de BIDEEW BOU BESS est en ligne sur la chaîne officielle : « ' . $t . ' ».'];
        }
    }
    // 2) Sorties musicales (Deezer)
    $dz = json_decode(bidew_remote('https://api.deezer.com/artist/' . BIDEEW_DEEZER_ARTIST . '/albums?limit=25'), true);
    foreach (($dz['data'] ?? []) as $a) {
        $type = $a['record_type'] === 'album' ? 'Nouvel album' : ($a['record_type'] === 'ep' ? 'Nouvel EP' : 'Nouveau single');
        $items[] = ['key' => 'dz:' . $a['id'], 'title' => $type . ' : ' . $a['title'], 'date' => $a['release_date'] . 'T12:00:00', 'cat' => $type, 'thumb' => $a['cover_xl'] ?? '', 'link' => $a['link'],
            'yt' => '', 'content' => '« ' . $a['title'] . ' » de BIDEEW BOU BESS est disponible sur les plateformes de streaming. Écouter sur Deezer : ' . $a['link']];
    }
    // 3) Flux RSS supplémentaires
    foreach (array_filter(array_map('trim', explode("\n", (string) get_option('bidew_auto_feeds')))) as $url) {
        $x = @simplexml_load_string(bidew_remote($url) ?: '<x/>'); if (!$x) continue;
        foreach (($x->channel->item ?? []) as $i) {
            $items[] = ['key' => 'rss:' . md5((string) ($i->guid ?: $i->link)), 'title' => (string) $i->title, 'date' => date('c', strtotime((string) $i->pubDate) ?: time()), 'cat' => 'Actualité',
                'thumb' => '', 'link' => (string) $i->link, 'yt' => '', 'content' => wp_strip_all_tags((string) $i->description) . "\n\nSource : " . (string) $i->link];
        }
    }
    return $items;
}

function bidew_autosync_run() {
    $mode = get_option('bidew_auto_mode', 'publish');
    if ($mode === 'off') return;
    if (!get_option('bidew_auto_since')) { update_option('bidew_auto_since', time() - 21 * DAY_IN_SECONDS); }  // 1re exécution : 3 semaines seulement, pas tout l'historique
    $since = (int) get_option('bidew_auto_since'); $n = 0;
    foreach (bidew_collect() as $it) {
        $ts = strtotime($it['date']);
        if (!$ts || $ts < $since || $ts > time() + DAY_IN_SECONDS || bidew_already($it['key'])) continue;
        $body = $it['yt'] ? $it['content'] . "\n\n" . bidew_watch($it['yt']) : $it['content'];
        $pid = wp_insert_post(['post_type' => 'post', 'post_status' => $mode, 'post_title' => wp_strip_all_tags($it['title']), 'post_content' => $body, 'post_date' => get_date_from_gmt(gmdate('Y-m-d H:i:s', $ts)),
            'post_category' => bidew_category($it['cat'])], true);
        if (is_wp_error($pid)) continue;
        update_post_meta($pid, '_bidew_src', $it['key']);
        if ($it['yt']) update_post_meta($pid, '_bidew_yt', $it['yt']);
        bidew_sideload($it['thumb'], $pid);
        if ($mode === 'publish') update_option('bidew_auto_last', ['title' => $it['title'], 'url' => get_permalink($pid), 'time' => time()]);
        $n++;
    }
    if ($n) { delete_transient('bidew_feed'); }
    update_option('bidew_auto_report', date_i18n('d/m/Y H:i') . ' — ' . $n . ' publication(s) ajoutée(s)', false);
}
