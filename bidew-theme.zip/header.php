<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0B0B0B">
<script>document.documentElement.classList.add("js");try{if(!localStorage.getItem("bw_ann"))document.documentElement.classList.add("has-ann")}catch(e){document.documentElement.classList.add("has-ann")}</script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open();
$cur = is_front_page() ? '' : (is_home() ? 'actualites' : (is_page() ? get_post_field('post_name', get_queried_object_id()) : ''));
?>
<a class="skip" href="#contenu">Aller au contenu</a>
<?php [$ann_tag, $ann_text, $ann_url] = bidew_announce(); ?>
<div class="announce" role="region" aria-label="Annonce"><a href="<?php echo esc_url($ann_url); ?>" data-ev="Announce"><?php if ($ann_tag) echo '<b>' . esc_html($ann_tag) . '</b> '; echo esc_html($ann_text); ?> <span>Voir →</span></a><button type="button" class="ann-x" aria-label="Fermer l'annonce">✕</button></div>
<header class="site-header">
  <button class="burger" aria-expanded="false" aria-controls="menu"><i aria-hidden="true"></i><b>Menu</b></button>
  <a class="logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Bideew Bou Bess, accueil">BIDEEW <span>BOU</span> BESS</a>
  <div class="hd-r">
    <a href="<?php echo esc_url(home_url('/actualites/')); ?>">Actualités</a>
    <a href="<?php echo esc_url(home_url('/contact/')); ?>">Booking</a>
  </div>
</header>
<div class="menu" id="menu">
  <div class="menu-panel">
    <button class="menu-close" type="button">Fermer ✕</button>
    <div class="flag-stripe" aria-hidden="true"></div>
    <nav aria-label="Menu principal">
      <a<?php echo is_front_page() ? ' class="cur"' : ''; ?> href="<?php echo esc_url(home_url('/')); ?>">Accueil</a>
      <?php foreach (bidew_nav_items() as $n) printf('<a%s href="%s">%s<small>%s</small></a>', $n['slug'] === $cur ? ' class="cur"' : '', esc_url($n['url']), esc_html($n['title']), esc_html($n['desc'])); ?>
    </nav>
    <div class="menu-foot"><?php foreach (bidew_socials() as $label => $url) printf('<a href="%s" target="_blank" rel="noopener me">%s</a>', esc_url($url), esc_html($label)); ?></div>
  </div>
</div>
<main id="contenu">