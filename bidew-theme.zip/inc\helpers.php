<?php
/* Données du site, navigation, actualités (articles + flux YouTube officiel) */
if (!defined('ABSPATH')) exit;

function bidew_data() {
    static $d = null;
    if ($d === null) $d = json_decode(file_get_contents(get_template_directory() . '/data/content.json'), true) ?: [];
    return $d;
}

function bidew_youtube_id($url) {
    if (preg_match('~(?:youtu\.be/|youtube\.com/(?:watch\?v=|embed/|shorts/))([\w-]{11})~', (string) $url, $m)) return $m[1];
    return '';
}
/* URL d'une image du thème (assets/img) ou URL absolue */
function bidew_img($f) { return preg_match('~^https?://~', $f) ? $f : get_template_directory_uri() . '/assets/img/' . ltrim($f, '/'); }
/* Attributs width/height d'une image du thème (évite les sauts de mise en page) */
function bidew_img_attrs($rel) {
    $s = @getimagesize(get_template_directory() . '/assets/img/' . ltrim($rel, '/'));
    return $s ? sprintf(' width="%d" height="%d"', $s[0], $s[1]) : '';
}
/* Bandeau d'annonce : réglage dans Réglages → Général, sinon dernier clip */
function bidew_announce() {
    $a = bidew_data()['announce'];
    if ($txt = get_option('bidew_announce_text')) return ['', $txt, get_option('bidew_announce_url') ?: home_url('/')];
    $last = get_option('bidew_auto_last');   /* dernière publication automatique, valable 21 jours */
    if ($last && time() - $last['time'] < 21 * DAY_IN_SECONDS) return ['Nouveau', $last['title'], $last['url']];
    return [$a['tag'], $a['text'], get_option('bidew_announce_url') ?: $a['url']];
}
function bidew_page_meta($slug) { $m = bidew_data()['pages_meta'][$slug] ?? null; return $m ?: ['', '']; }
function bidew_yt_thumb($id) { return 'https://i.ytimg.com/vi/' . rawurlencode($id) . '/hqdefault.jpg'; }
function bidew_watch($id) { return 'https://www.youtube.com/watch?v=' . rawurlencode($id); }

function bidew_verify_badge($id) {
    if (get_post_meta($id, 'verifie', true) !== '1') echo '<span class="verify">À vérifier</span>';
}

function bidew_nav_items() {
    $items = [];
    foreach (bidew_data()['nav'] as $n) $items[] = $n + ['url' => home_url('/' . $n['slug'] . '/')];
    return $items;
}

/* Plage du monde 3D par page (début:fin du trajet de la caméra) */
function bidew_world_range() {
    $map = ['histoire' => '.08:.75', 'discographie' => '.02:.4', 'videos' => '.3:.6', 'actualites' => '.1:.35', 'membres' => '.5:.8', 'engagements' => '.6:.88', 'contact' => '.82:1'];
    if (is_front_page()) return '0:1';
    if (is_home()) return $map['actualites'];
    if (is_page()) return $map[get_post_field('post_name', get_queried_object_id())] ?? '0:1';
    return '0:1';
}

/* Flux YouTube officiel (mis en cache 6 h) */
function bidew_feed() {
    $cached = get_transient('bidew_feed');
    if ($cached !== false) return $cached;
    $id = get_option('bidew_yt_channel') ?: bidew_data()['channel']['id'];
    $items = [];
    $r = wp_remote_get('https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode($id), ['timeout' => 6]);
    if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200 && function_exists('simplexml_load_string')) {
        $xml = @simplexml_load_string(wp_remote_retrieve_body($r));
        if ($xml) foreach ($xml->entry as $e) {
            $yt = $e->children('http://www.youtube.com/xml/schemas/2015');
            $items[] = ['date' => substr((string) $e->published, 0, 10), 'title' => (string) $e->title, 'yt' => (string) $yt->videoId];
        }
    }
    set_transient('bidew_feed', $items, $items ? 6 * HOUR_IN_SECONDS : 10 * MINUTE_IN_SECONDS);
    return $items;
}

/* Actualités : articles WordPress + chaîne officielle + presse (liste du thème), du plus récent au plus ancien */
function bidew_news($limit = 0) {
    $news = [];
    foreach (get_posts(['post_type' => 'post', 'numberposts' => 20]) as $p) {
        $cats = get_the_category($p->ID);
        $news[] = ['date' => get_the_date('Y-m-d', $p), 'tag' => $cats ? $cats[0]->name : 'Actualité', 'title' => get_the_title($p), 'text' => wp_strip_all_tags(get_the_excerpt($p)),
            'url' => get_permalink($p), 'thumb' => get_the_post_thumbnail_url($p, 'large') ?: ''];
    }
    $posted = $GLOBALS['wpdb']->get_col("SELECT meta_value FROM {$GLOBALS['wpdb']->postmeta} WHERE meta_key = '_bidew_yt'");
    $feed = array_values(array_filter(bidew_feed(), fn($f) => !in_array($f['yt'], $posted, true))); $fromFeed = [];
    if ($feed) {
        $byDate = [];
        foreach ($feed as $f) $byDate[$f['date']][] = $f;
        foreach ($byDate as $date => $group) {
            $first = $group[0]; $n = count($group);
            $fromFeed[] = $n > 1
                ? ['date' => $date, 'tag' => 'Nouveaux titres', 'title' => "$n titres mis en ligne : " . implode(', ', array_slice(array_column($group, 'title'), 0, 4)) . ($n > 4 ? '…' : ''), 'text' => 'Publiés sur la chaîne officielle.', 'yt' => $first['yt']]
                : ['date' => $date, 'tag' => 'YouTube', 'title' => $first['title'], 'text' => 'Publié sur la chaîne officielle.', 'yt' => $first['yt']];
        }
    }
    $curated = bidew_data()['news']; $dates = array_column($curated, 'date');
    $fromFeed = array_values(array_filter($fromFeed, fn($f) => !in_array($f['date'], $dates, true)));
    $news = array_merge($news, $fromFeed, $curated);    usort($news, fn($a, $b) => strcmp($b['date'], $a['date']));
    return $limit ? array_slice($news, 0, $limit) : $news;
}
