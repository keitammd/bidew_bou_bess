<?php get_header(); ?>
<section class="hero" style="min-height:80vh">
  <p class="eyebrow">Erreur 404</p>
  <h1 style="font-size:clamp(2.5rem,9vw,7rem)">Page <em>introuvable</em></h1>
  <p class="lead">Cette page n'existe pas ou a été déplacée.</p>
  <div class="cta-row"><a class="btn primary" href="<?php echo esc_url(home_url('/')); ?>">Retour à l'accueil</a></div>
</section>
<?php get_footer();
