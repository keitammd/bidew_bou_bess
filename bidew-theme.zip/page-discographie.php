<?php get_header();
bidew_page_hero('discographie', 'Discographie', 'complète', 'Albums, singles et collaborations, avec les titres et les plateformes d\'écoute.'); ?>
<section class="sec"><?php bidew_head('Écouter partout', 'Les profils officiels du groupe sur les principales plateformes.', 'Plateformes'); bidew_render_platforms(); ?></section>
<section class="sec white"><?php bidew_head('Albums', 'Quatre albums de 1999 à 2025.', 'Albums'); bidew_render_albums(true); ?></section>
<section class="sec"><?php bidew_head('Singles & collaborations', 'Les titres qui ont jalonné le parcours.', 'Repères'); bidew_render_singles(); ?></section>
<?php get_footer();