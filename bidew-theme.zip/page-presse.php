<?php get_header();
bidew_page_hero('presse', 'Presse', '& EPK', 'Tout ce qu\'il faut pour parler du groupe : biographie en français et en anglais, chiffres clés, discographie et photos.'); ?>
<section class="sec"><?php bidew_head('Biographie', 'Deux versions prêtes à copier-coller.', 'Bio'); bidew_render_epk('bio'); ?></section>
<section class="sec white"><?php bidew_head('Fiche express', 'L\'essentiel en un coup d\'œil.', 'Chiffres'); bidew_render_epk('facts'); echo '<div style="margin-top:34px">'; bidew_render_stats(); echo '</div>'; ?></section>
<section class="sec"><?php bidew_head('Photos pour la presse', 'Téléchargez les visuels. Droits à confirmer avec le groupe avant toute publication.', 'Visuels'); bidew_render_epk('photos'); ?></section>
<section class="sec dark"><?php bidew_head('Discographie', 'Quatre albums, de 1999 à 2025.', 'Œuvres'); bidew_render_albums(false); ?><div class="more-row"><button type="button" class="btn" onclick="print()">Imprimer cette page</button></div></section>
<?php bidew_cta('Interview, programmation, partenariat ?', 'Contacter le groupe', home_url('/contact/'));
get_footer();