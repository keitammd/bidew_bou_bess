<?php get_header(); ?>
<section class="page-body" style="padding-top:160px">
  <div class="sec-head"><div class="rule"></div><h2><?php echo is_home() ? 'Actualités' : esc_html(wp_strip_all_tags(get_the_archive_title())); ?></h2></div>
  <div class="grid">
  <?php while (have_posts()) : the_post(); ?>
    <article class="card"><a href="<?php the_permalink(); ?>">
      <?php if (has_post_thumbnail()) the_post_thumbnail('medium_large'); ?>
      <div class="card-body"><small><?php echo esc_html(get_the_date()); ?></small><h3><?php the_title(); ?></h3><p><?php echo esc_html(get_the_excerpt()); ?></p></div></a></article>
  <?php endwhile; ?>
  </div>
  <?php the_posts_pagination(); ?>
</section>
<?php get_footer();
