<?php get_header();
bidew_page_hero('histoire', 'Histoire', "d'une famille", 'Du village de Podor aux scènes du monde : le récit de Bideew Bou Bess, chapitre après chapitre.'); ?>
<section class="sec"><?php bidew_render_story(); ?></section>
<?php bidew_cta("La suite s'écrit maintenant", 'Découvrir la discographie', home_url('/discographie/'));
get_footer();
