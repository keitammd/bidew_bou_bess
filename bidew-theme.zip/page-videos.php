<?php get_header();
bidew_page_hero('videos', 'Vidéos', 'officielles', 'Clips et sessions live, à regarder sans quitter le site.'); ?>
<section class="sec"><?php bidew_render_videos(); bidew_link_more(bidew_data()['channel']['url'], 'Toute la chaîne YouTube', true); ?></section>
<?php get_footer();