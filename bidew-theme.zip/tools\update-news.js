/* Met à jour data/content.json avec les nouveautés (chaîne YouTube officielle + Deezer) puis régénère l'aperçu.
   Usage : node tools/update-news.js          (ajoute les nouveautés des 21 derniers jours, sans doublon)
           node tools/update-news.js --all    (tout l'historique)  */
const fs = require('fs'), path = require('path'), cp = require('child_process');
const file = path.join(__dirname, '..', 'data', 'content.json');
const d = JSON.parse(fs.readFileSync(file, 'utf8'));
const all = process.argv.includes('--all');
const since = all ? 0 : Date.now() - 21 * 864e5;
const get = async u => { const r = await fetch(u, { headers: { 'user-agent': 'BideewSite/1.0' } }); if (!r.ok) throw new Error(u + ' ' + r.status); return r.text(); };

(async () => {
  const known = new Set(d.news.map(n => n.yt).filter(Boolean));
  const keys = new Set(d.news.map(n => n.src).filter(Boolean));
  const add = [];
  try {
    const xml = await get('https://www.youtube.com/feeds/videos.xml?channel_id=' + d.channel.id);
    for (const m of xml.matchAll(/<entry>[\s\S]*?<\/entry>/g)) {
      const e = m[0], id = (e.match(/<yt:videoId>(.*?)<\/yt:videoId>/) || [])[1], t = (e.match(/<title>(.*?)<\/title>/) || [])[1], p = (e.match(/<published>(.*?)<\/published>/) || [])[1];
      if (!id || known.has(id) || Date.parse(p) < since) continue;
      add.push({ date: p.slice(0, 10), tag: 'Nouveau clip', title: t.replace(/&amp;/g, '&').replace(/&#39;/g, "'"), yt: id, text: 'Publié sur la chaîne officielle.', src: 'yt:' + id });
    }
  } catch (e) { console.warn('YouTube :', e.message); }
  try {
    const dz = JSON.parse(await get('https://api.deezer.com/artist/2930481/albums?limit=50')).data || [];
    for (const a of dz) {
      const k = 'dz:' + a.id;
      if (keys.has(k) || Date.parse(a.release_date) < since) continue;
      if (d.news.some(n => n.date === a.release_date && /album|single/i.test(n.tag))) continue;   // déjà couvert à la main
      const tag = a.record_type === 'album' ? 'Album' : a.record_type === 'ep' ? 'EP' : 'Singles';
      add.push({ date: a.release_date, tag, title: (tag === 'Album' ? 'Nouvel album : ' : 'Nouveau single : ') + a.title, text: 'Disponible sur les plateformes de streaming.', url: a.link, src: k });
    }
  } catch (e) { console.warn('Deezer :', e.message); }
  if (!add.length) return console.log('Rien de nouveau.');
  d.news = d.news.concat(add).sort((a, b) => b.date.localeCompare(a.date));
  if (d.announce && add[0]) { const a = add.sort((x, y) => y.date.localeCompare(x.date))[0]; d.announce.text = a.title; d.announce.url = a.url || 'https://www.youtube.com/watch?v=' + a.yt; }
  fs.writeFileSync(file, JSON.stringify(d, null, 2));
  console.log(add.length + ' actualité(s) ajoutée(s) :', add.map(a => a.title).join(' | '));
  cp.execSync('node ' + JSON.stringify(path.join(__dirname, 'build-preview.js')), { stdio: 'inherit' });
})();
