<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
    register_nav_menu('primary', 'Menu principal (facultatif : le menu par défaut est généré)');
});

add_action('wp_enqueue_scripts', function () {
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('bidew-fonts', get_template_directory_uri() . '/assets/css/fonts.css', [], $v);
    wp_enqueue_style('bidew-main', get_template_directory_uri() . '/assets/css/main.css', ['bidew-fonts'], $v);
    wp_enqueue_script('bidew-main', get_template_directory_uri() . '/assets/js/main.js', [], $v, true);
});

/* Types de contenus */
add_action('init', function () {
    $types = [
        'jalon'      => ['Chapitres d\'histoire', 'Chapitre', 'dashicons-backup', ['title', 'editor', 'page-attributes'], false],
        'album'      => ['Albums', 'Album', 'dashicons-album', ['title', 'editor', 'thumbnail', 'page-attributes'], false],
        'video'      => ['Vidéos', 'Vidéo', 'dashicons-video-alt3', ['title', 'thumbnail', 'page-attributes'], false],
        'membre'     => ['Membres', 'Membre', 'dashicons-groups', ['title', 'editor', 'thumbnail', 'page-attributes'], false],
        'engagement' => ['Engagements', 'Engagement', 'dashicons-heart', ['title', 'editor', 'page-attributes'], false],
        'concert'    => ['Concerts', 'Concert', 'dashicons-calendar-alt', ['title', 'editor', 'page-attributes'], false],
        'photo'      => ['Photos (galerie)', 'Photo', 'dashicons-format-gallery', ['title', 'thumbnail', 'page-attributes'], false],
        'partenaire' => ['Partenaires', 'Partenaire', 'dashicons-networking', ['title', 'editor', 'page-attributes'], false],
        'presse'     => ['Revue de presse', 'Article de presse', 'dashicons-media-document', ['title', 'page-attributes'], false],
    ];
    foreach ($types as $slug => [$plural, $single, $icon, $supports, $archive]) {
        register_post_type($slug, [
            'labels' => ['name' => $plural, 'singular_name' => $single, 'add_new_item' => "Ajouter : $single"],
            'public' => true, 'publicly_queryable' => false, 'exclude_from_search' => true, 'has_archive' => $archive,
            'menu_icon' => $icon, 'supports' => $supports, 'show_in_rest' => true, 'rewrite' => false,
        ]);
    }
});

/* Champs personnalisés */
function bidew_fields() {
    return [
        'jalon'  => ['annee' => ['Année', 'text'], 'kicker' => ['Étiquette (ex. Chapitre I)', 'text'],
                     'sources' => ['Sources (une par ligne : Nom|URL)', 'textarea'], 'verifie' => ['Information vérifiée et sourcée', 'check']],
        'album'  => ['annee' => ['Année de sortie', 'text'], 'lien_ecoute' => ['Lien d\'écoute (URL YouTube)', 'url'],
                     'cover' => ['Pochette (nom de fichier dans assets/img ou URL ; sinon image à la une)', 'text'],
                     'liens' => ['Autres liens d\'écoute (une par ligne : Nom|URL)', 'textarea'],
                     'pistes' => ['Pistes (une par ligne : Titre|ID YouTube)', 'textarea'], 'verifie' => ['Information vérifiée et sourcée', 'check']],
        'engagement' => ['img' => ['Image (nom de fichier dans assets/img ou URL)', 'text']],
        'video'  => ['url_video' => ['URL YouTube', 'url']],
        'membre' => ['role' => ['Rôle', 'text']],
        'concert' => ['date' => ['Date (AAAA-MM-JJ)', 'text'], 'ville' => ['Ville', 'text'], 'lieu' => ['Lieu / salle / festival', 'text'], 'billet' => ['Lien billetterie', 'url']],
        'photo' => ['cat' => ['Catégorie (concerts, engagements, groupe, visuels, senegal)', 'text']],
        'partenaire' => ['groupe' => ['Groupe (ex. Institutions, ONG et santé)', 'text'], 'since' => ['Depuis / année', 'text'], 'url' => ['Site web', 'url']],
        'presse' => ['date_label' => ['Date affichée (ex. 12 mars 2027)', 'text'], 'source' => ['Média / source', 'text'], 'url' => ['Lien de l\'article', 'url']],
    ];
}

add_action('add_meta_boxes', function () {
    foreach (array_keys(bidew_fields()) as $type) add_meta_box('bidew_meta', 'Détails', 'bidew_meta_box', $type, 'normal', 'high');
});

function bidew_meta_box($post) {
    wp_nonce_field('bidew_save', 'bidew_nonce');
    foreach (bidew_fields()[$post->post_type] as $key => [$label, $kind]) {
        $val = get_post_meta($post->ID, $key, true);
        echo '<p><label>';
        if ($kind === 'check') printf('<input type="checkbox" name="%s" value="1" %s> %s', esc_attr($key), checked($val, '1', false), esc_html($label));
        elseif ($kind === 'textarea') printf('%s<br><textarea class="widefat" rows="5" name="%s">%s</textarea>', esc_html($label), esc_attr($key), esc_textarea($val));
        else printf('%s<br><input class="widefat" type="%s" name="%s" value="%s">', esc_html($label), esc_attr($kind), esc_attr($key), esc_attr($val));
        echo '</label></p>';
    }
}

add_action('save_post', function ($id) {
    if (!isset($_POST['bidew_nonce']) || !wp_verify_nonce($_POST['bidew_nonce'], 'bidew_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $id)) return;
    foreach (bidew_fields()[get_post_type($id)] ?? [] as $key => [$label, $kind]) {
        if ($kind === 'check') { isset($_POST[$key]) ? update_post_meta($id, $key, '1') : delete_post_meta($id, $key); continue; }
        if (!isset($_POST[$key])) continue;
        $raw = wp_unslash($_POST[$key]);
        update_post_meta($id, $key, $kind === 'url' ? esc_url_raw($raw) : ($kind === 'textarea' ? sanitize_textarea_field($raw) : sanitize_text_field($raw)));
    }
});

/* Formulaire de booking (sans plugin) */
function bidew_handle_booking() {
    $back = wp_get_referer() ?: home_url('/');
    if (!isset($_POST['bidew_booking_nonce']) || !wp_verify_nonce($_POST['bidew_booking_nonce'], 'bidew_booking') || !empty($_POST['website'])) {
        wp_safe_redirect(add_query_arg('booking', 'error', $back) . '#booking'); exit;
    }
    $nom = sanitize_text_field(wp_unslash($_POST['nom'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $type = sanitize_text_field(wp_unslash($_POST['type'] ?? ''));
    $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
    if (!$nom || !is_email($email) || !$message) { wp_safe_redirect(add_query_arg('booking', 'invalid', $back) . '#booking'); exit; }
    $to = get_option('bidew_booking_email') ?: get_option('admin_email');
    $ok = wp_mail($to, "[Booking] $type - $nom", "Nom: $nom\nEmail: $email\nType: $type\n\n$message", ["Reply-To: $nom <$email>"]);
    wp_safe_redirect(add_query_arg('booking', $ok ? 'ok' : 'error', $back) . '#booking'); exit;
}
add_action('admin_post_nopriv_bidew_booking', 'bidew_handle_booking');
add_action('admin_post_bidew_booking', 'bidew_handle_booking');

add_action('admin_init', function () {
    register_setting('general', 'bidew_booking_email', ['type' => 'string', 'sanitize_callback' => 'sanitize_email']);
    add_settings_field('bidew_booking_email', 'Email de booking', function () {
        printf('<input type="email" class="regular-text" name="bidew_booking_email" value="%s">', esc_attr(get_option('bidew_booking_email')));
    }, 'general');
    foreach (['bidew_analytics_domain' => ['Mesure d\'audience : domaine Plausible (sans cookie), ex. mondomaine.com', 'sanitize_text_field'], 'bidew_announce_text' => ['Bandeau d\'annonce : texte (vide = dernier clip)', 'sanitize_text_field'], 'bidew_announce_url' => ['Bandeau d\'annonce : lien', 'esc_url_raw']] as $opt => [$label, $cb]) {
        register_setting('general', $opt, ['type' => 'string', 'sanitize_callback' => $cb]);
        add_settings_field($opt, $label, function () use ($opt) { printf('<input type="text" class="regular-text" name="%s" value="%s">', esc_attr($opt), esc_attr(get_option($opt))); }, 'general');
    }
    register_setting('general', 'bidew_yt_channel', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
    add_settings_field('bidew_yt_channel', 'ID de la chaîne YouTube (flux d\'actualités)', function () {
        printf('<input type="text" class="regular-text" name="bidew_yt_channel" placeholder="UCHHX-_CbCEOqadgDsyzy6xw" value="%s">', esc_attr(get_option('bidew_yt_channel')));
    }, 'general');
});

require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/render.php';
require get_template_directory() . '/inc/marketing.php';
require get_template_directory() . '/inc/autopublish.php';
require get_template_directory() . '/inc/seed.php';
