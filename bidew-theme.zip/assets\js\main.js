/* BIDEW BOU BESS — menu, diaporama, apparitions, compteurs, galerie, lecteur YouTube à la demande, mesure d'événements */
(() => {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
const track = (name, props) => { try { if (window.plausible) window.plausible(name, props ? { props } : undefined); } catch (e) {} };

/* En-tête : transparent sur le diaporama, noir ailleurs ; bouton « haut de page » */
const header = $('.site-header'), hasHero = !!$('.hero-slider'), totop = $('.totop');
const onScroll = () => { header.classList.toggle('solid', !hasHero || scrollY > 40); if (totop) totop.hidden = scrollY < 900; };
addEventListener('scroll', onScroll, { passive: true }); onScroll();
if (totop) totop.addEventListener('click', () => scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }));

/* Bandeau d'annonce (mémorisé à la fermeture) */
$('.ann-x')?.addEventListener('click', () => { document.documentElement.classList.remove('has-ann'); try { localStorage.setItem('bw_ann', '1'); } catch (e) {} });

/* Menu plein écran : focus piégé, fond inerte */
const burger = $('.burger'), menuPanel = $('.menu-panel');
const setMenu = o => {
  document.body.classList.toggle('menu-open', o); burger.setAttribute('aria-expanded', o);
  $$('#contenu, footer, .news-band').forEach(e => { o ? e.setAttribute('inert', '') : e.removeAttribute('inert'); });
  if (o) $('.menu-close').focus(); else burger.focus();
};
burger.addEventListener('click', () => setMenu(true));
document.addEventListener('click', e => { if (e.target.closest('.menu-close') || e.target.classList.contains('menu')) setMenu(false); });
addEventListener('keydown', e => {
  if (!document.body.classList.contains('menu-open')) return;
  if (e.key === 'Escape') return setMenu(false);
  if (e.key === 'Tab') { const f = $$('a,button', menuPanel); const a = f[0], z = f[f.length - 1]; if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } }
});

/* Diaporama d'accueil : lecture auto, pause, flèches, pastilles */
const slider = $('.hero-slider');
if (slider) {
  const slides = $$('.slide', slider), dots = $$('.dots button', slider);
  let i = 0, timer, paused = reduce;
  const go = n => {
    i = (n + slides.length) % slides.length;
    slides.forEach((s, k) => { s.classList.toggle('is-active', k === i); s.setAttribute('aria-hidden', k !== i); });
    dots.forEach((d, k) => { d.classList.toggle('on', k === i); d.setAttribute('aria-current', k === i); });
  };
  const play = () => { clearInterval(timer); if (!paused) timer = setInterval(() => go(i + 1), 7000); };
  const pb = document.createElement('button'); pb.type = 'button'; pb.className = 'pause'; pb.setAttribute('aria-label', paused ? 'Lancer le diaporama' : 'Mettre le diaporama en pause'); pb.textContent = paused ? '▶' : '❚❚';
  pb.addEventListener('click', () => { paused = !paused; pb.textContent = paused ? '▶' : '❚❚'; pb.setAttribute('aria-label', paused ? 'Lancer le diaporama' : 'Mettre le diaporama en pause'); play(); });
  $('.dots', slider).prepend(pb);
  $('.prev', slider).addEventListener('click', () => { go(i - 1); play(); });
  $('.next', slider).addEventListener('click', () => { go(i + 1); play(); });
  dots.forEach((d, k) => d.addEventListener('click', () => { go(k); play(); }));
  slider.addEventListener('mouseenter', () => clearInterval(timer)); slider.addEventListener('mouseleave', play);
  slider.addEventListener('focusin', () => clearInterval(timer)); slider.addEventListener('focusout', play);
  document.addEventListener('visibilitychange', () => document.hidden ? clearInterval(timer) : play());
  go(0); play();
}

/* Apparition au défilement + compteurs animés */
const countUp = el => {
  const t = el.textContent.trim(), m = t.match(/^([\d\s.,]+)(.*)$/); if (!m) return;
  const raw = m[1].trim(), n = parseFloat(raw.replace(/\s/g, '').replace(',', '.'));
  if (isNaN(n) || (/^\d{4}$/.test(raw) && n > 1800 && n < 2200)) return;
  const dec = (raw.split(',')[1] || '').length, suffix = m[2];
  const fmt = v => v.toLocaleString('fr-FR', { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suffix;
  if (reduce) return; const t0 = performance.now(), d = 1300;
  const tick = now => { const p = Math.min(1, (now - t0) / d), e = 1 - Math.pow(1 - p, 3); el.textContent = fmt(n * e); if (p < 1) requestAnimationFrame(tick); else el.textContent = t; };
  requestAnimationFrame(tick);
};
const io = new IntersectionObserver(es => es.forEach(en => {
  if (!en.isIntersecting) return; en.target.classList.add('in'); io.unobserve(en.target);
  const b = en.target.matches('.stat') ? $('b', en.target) : null; if (b) countUp(b);
}), { threshold: .1 });
$$('.reveal').forEach(el => io.observe(el));

/* Lecteur YouTube : l'iframe n'est chargée qu'au clic */
document.addEventListener('click', e => {
  const b = e.target.closest('.yt'); if (!b) return;
  const f = document.createElement('iframe');
  f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(b.dataset.yt) + '?autoplay=1&rel=0';
  f.allow = 'autoplay; encrypted-media; picture-in-picture'; f.allowFullscreen = true; f.title = b.getAttribute('aria-label') || 'Vidéo';
  track('Video', { title: b.getAttribute('aria-label') });
  b.replaceWith(f);
});

/* Copier les biographies (page presse) */
document.addEventListener('click', e => {
  const b = e.target.closest('.copy'); if (!b) return;
  const txt = document.getElementById(b.dataset.copy)?.textContent.trim(); if (!txt) return;
  (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => { b.textContent = 'Copié ✓'; }).catch(() => { b.textContent = 'Sélectionnez le texte'; });
  setTimeout(() => { b.textContent = 'Copier le texte'; }, 2200); track('Bio copy');
});

/* Mesure d'audience : événements nommés (data-ev), sans cookie, si Plausible est actif */
document.addEventListener('click', e => { const a = e.target.closest('[data-ev]'); if (a) track(a.dataset.ev.split(':')[0].trim(), { label: a.dataset.ev }); });

/* Galerie : filtres par catégorie + visionneuse accessible */
const filters = $$('.filters button');
filters.forEach(b => b.addEventListener('click', () => {
  filters.forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); });
  $$('.g-cat').forEach(s => { s.hidden = b.dataset.f !== 'all' && s.dataset.cat !== b.dataset.f; });
}));
const items = $$('.g-item:not([download])');
if (items.length) {
  const lb = document.createElement('div'); lb.className = 'lb'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Photo agrandie');
  lb.innerHTML = '<button class="x" aria-label="Fermer">✕</button><button class="pv" aria-label="Photo précédente">‹</button><img alt=""><p></p><button class="nx" aria-label="Photo suivante">›</button>';
  document.body.append(lb);
  let cur = 0, list = [], opener = null;
  const show = n => { cur = (n + list.length) % list.length; const a = list[cur]; $('img', lb).src = a.href; $('img', lb).alt = $('img', a).alt; $('p', lb).textContent = a.dataset.caption; };
  const close = () => { lb.classList.remove('open'); opener?.focus(); };
  items.forEach(a => a.addEventListener('click', e => { e.preventDefault(); opener = a; list = items.filter(x => !x.closest('[hidden]')); show(list.indexOf(a)); lb.classList.add('open'); $('.x', lb).focus(); track('Photo', { label: a.dataset.caption }); }));
  lb.addEventListener('click', e => { if (e.target === lb || e.target.classList.contains('x')) close(); if (e.target.classList.contains('pv')) show(cur - 1); if (e.target.classList.contains('nx')) show(cur + 1); });
  addEventListener('keydown', e => { if (!lb.classList.contains('open')) return; if (e.key === 'Escape') close(); if (e.key === 'ArrowLeft') show(cur - 1); if (e.key === 'ArrowRight') show(cur + 1); });
}

/* Décalage progressif des cartes + titres de section animés */
$$('.grid,.latest-grid,.list-news,.platforms,.stats').forEach(g => $$(':scope > .reveal', g).forEach((el, k) => el.style.setProperty('--d', Math.min(k, 8) * 0.08 + 's')));
$$('.sec-head').forEach(h => { h.classList.add('reveal'); io.observe(h); });

/* Compte à rebours de l'annonce */
const cd = $('.countdown');
if (cd) {
  const t = Date.parse(cd.dataset.iso), cells = $$('b', cd);
  const upd = () => {
    const s = Math.floor((t - Date.now()) / 1000);
    if (s <= 0) { cd.hidden = true; return false; }
    [Math.floor(s / 86400), Math.floor(s % 86400 / 3600), Math.floor(s % 3600 / 60), s % 60].forEach((v, k) => { cells[k].textContent = String(v).padStart(2, '0'); });
    return true;
  };
  if (upd() && !reduce) { const id = setInterval(() => { if (!upd()) clearInterval(id); }, 1000); }
}
})();