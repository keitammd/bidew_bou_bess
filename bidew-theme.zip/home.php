<?php get_header();
bidew_page_hero('actualites', 'Actualités', 'et presse', 'Nouveautés mises à jour depuis la chaîne officielle, puis la revue de presse sur le groupe.'); ?>
<?php bidew_render_headline(); ?>
<section class="sec"><?php bidew_render_news(); ?></section>
<section class="sec white"><?php bidew_head('Revue de presse', 'Ce que disent les médias et les institutions du groupe.', 'Presse'); bidew_render_press(); ?></section>
<?php get_footer();