<?php
/* Blocs d'affichage partagés par l'accueil et les pages */
if (!defined('ABSPATH')) exit;

function bidew_head($title, $intro, $kicker = '') {
    echo '<div class="sec-head reveal">' . ($kicker ? '<p class="eyebrow">' . esc_html($kicker) . '</p>' : '') . '<div class="rule"></div><h2>' . esc_html($title) . '</h2><p>' . esc_html($intro) . '</p></div>';
}

function bidew_page_hero($slug, $title, $accent, $intro) {
    $label = '';
    foreach (bidew_data()['nav'] as $n) if ($n['slug'] === $slug) $label = $n['title'];
    printf('<section class="page-hero"><p class="crumbs"><a href="%s">Accueil</a> / %s</p><h1>%s <em>%s</em></h1><p>%s</p></section>',
        esc_url(home_url('/')), esc_html($label), esc_html($title), esc_html($accent), esc_html($intro));
}

function bidew_portal($word) { echo '<div class="portal" aria-hidden="true"><span>' . esc_html($word) . '</span></div>'; }

function bidew_link_more($url, $label, $primary = false) {
    printf('<div class="more-row"><a class="btn%s" href="%s">%s</a></div>', $primary ? ' primary' : '', esc_url($url), esc_html($label));
}

function bidew_cta($title, $label, $url) {
    printf('<section class="cta-band"><div class="reveal"><h2>%s</h2><a class="btn primary" href="%s">%s</a></div></section>', esc_html($title), esc_url($url), esc_html($label));
}

/* Actualités */
function bidew_news_card($n, $feat = false) {
    $url = $n['url'] ?? (!empty($n['yt']) ? bidew_watch($n['yt']) : '#');
    $img = $n['thumb'] ?? '';
    if (!$img && !empty($n['yt'])) $img = bidew_yt_thumb($n['yt']);
    $ext = strpos($url, home_url()) !== 0;
    printf('<article class="card reveal%s"><a href="%s"%s>', $feat ? ' feat' : '', esc_url($url), $ext ? ' target="_blank" rel="noopener"' : '');
    if ($img) printf('<div class="thumb"><img src="%s" alt="" loading="lazy">%s</div>', esc_url($img), !empty($n['yt']) ? '<span class="play" aria-hidden="true"></span>' : '');
    printf('<div class="card-body"><span class="tag">%s</span><span class="date">%s</span><h3>%s</h3><p>%s</p></div></a></article>',
        esc_html($n['tag']), esc_html($n['label'] ?? wp_date('j F Y', strtotime($n['date'] . ' 12:00'))), esc_html($n['title']), esc_html($n['text']));
}

function bidew_render_news($limit = 0, $mode = 'grid') {
    $items = bidew_news($limit);
    if ($mode === 'latest') { echo '<div class="latest-grid">'; foreach ($items as $i => $n) bidew_news_card($n, $i === 0); echo '</div>'; return; }
    echo '<div class="list-news">'; foreach ($items as $n) bidew_news_card($n); echo '</div>';
}

/* Histoire */
function bidew_sources_links($raw) {
    $out = '';
    foreach (preg_split('/\R/', (string) $raw) as $line) {
        $p = array_map('trim', explode('|', $line, 2));
        if (count($p) === 2 && $p[0] && $p[1]) $out .= sprintf('<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url($p[1]), esc_html($p[0]));
    }
    return $out;
}

function bidew_chapters() { return new WP_Query(['post_type' => 'jalon', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'no_found_rows' => true]); }

function bidew_render_story() {
    $r = bidew_chapters(); echo '<div class="story">';
    while ($r->have_posts()) : $r->the_post(); $id = get_the_ID(); $src = bidew_sources_links(get_post_meta($id, 'sources', true)); ?>
      <article class="chapter"><div class="when reveal"><div class="big"><?php echo esc_html(get_post_meta($id, 'annee', true) ?: '—'); ?></div><small><?php echo esc_html(get_post_meta($id, 'kicker', true)); ?></small></div>
        <div class="txt reveal"><h3><?php the_title(); ?></h3><?php the_content(); ?>
          <div class="src"><?php if ($src) echo '<span>Sources :</span>' . $src; bidew_verify_badge($id); ?></div></div></article>
    <?php endwhile; wp_reset_postdata(); echo '</div>';
    echo '<p class="note">' . esc_html(bidew_data()['faq_unverified']) . ' Les éléments marqués « À vérifier » proviennent de sources publiques qui divergent parfois ; ils seront validés avec le groupe avant publication définitive.</p>';
    echo '<div class="sec-head reveal" style="margin-top:80px"><div class="rule"></div><h2>Sources</h2></div><ul class="sources-list">';
    foreach (bidew_data()['sources'] as [$l, $u]) printf('<li><a href="%s" target="_blank" rel="noopener">%s</a></li>', esc_url($u), esc_html($l));
    echo '</ul>';
}

function bidew_render_timeline() {
    $r = bidew_chapters(); echo '<ol class="timeline-s">';
    while ($r->have_posts()) : $r->the_post();
        printf('<li class="reveal"><b>%s</b>%s</li>', esc_html(get_post_meta(get_the_ID(), 'annee', true) ?: '—'), esc_html(get_the_title()));
    endwhile; wp_reset_postdata(); echo '</ol>';
}

/* Discographie */
function bidew_render_albums($full = false) {
    $r = new WP_Query(['post_type' => 'album', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'no_found_rows' => true]);
    $channel = bidew_data()['channel']['url']; echo '<div class="grid">';
    while ($r->have_posts()) : $r->the_post(); $id = get_the_ID(); $link = get_post_meta($id, 'lien_ecoute', true); $an = get_post_meta($id, 'annee', true); $vid = bidew_youtube_id($link); ?>
      <article class="card reveal"><div class="cover">
        <?php $cover = get_post_meta($id, 'cover', true);
        if (has_post_thumbnail()) the_post_thumbnail('large');
        elseif ($cover) printf('<img src="%s" alt="Pochette de %s" loading="lazy">', esc_url(bidew_img($cover)), esc_attr(get_the_title()));
        elseif ($vid) printf('<img src="%s" alt="" loading="lazy">', esc_url(bidew_yt_thumb($vid)));
        else echo '<b>' . esc_html(substr($an, -2)) . '</b>'; ?>
        <?php if ($link) : ?><a class="cover-link" href="<?php echo esc_url($link); ?>" target="_blank" rel="noopener" aria-label="Écouter <?php echo esc_attr(get_the_title()); ?>"><span class="play" aria-hidden="true"></span></a><?php endif; ?>
      </div><div class="card-body"><small><?php echo esc_html($an); ?></small><h3><?php the_title(); ?></h3><?php bidew_verify_badge($id); ?>
        <div class="entry-sm"><?php echo wp_kses_post(wpautop(get_the_content()));
        if ($full) { $tr = ''; foreach (preg_split('/\R/', (string) get_post_meta($id, 'pistes', true)) as $line) { $p = array_map('trim', explode('|', $line, 2)); if (count($p) === 2 && $p[0]) $tr .= sprintf('<li><a href="%s" target="_blank" rel="noopener">%s</a></li>', esc_url(bidew_watch($p[1])), esc_html($p[0])); } if ($tr) echo '<ol class="tracks">' . $tr . '</ol>'; } ?></div>
        <p class="alinks"><a class="more" href="<?php echo esc_url($link ?: $channel); ?>" target="_blank" rel="noopener"><?php echo $link ? 'YouTube' : 'Chaîne YouTube'; ?></a><?php foreach (preg_split('/\R/', (string) get_post_meta($id, 'liens', true)) as $ln) { $p = array_map('trim', explode('|', $ln, 2)); if (count($p) === 2 && $p[1]) printf(' <a class="more" href="%s" target="_blank" rel="noopener">%s</a>', esc_url($p[1]), esc_html($p[0])); } ?></p></div></article>
    <?php endwhile; wp_reset_postdata(); echo '</div>';
}

function bidew_render_singles() {
    echo '<ol class="timeline-s">';
    foreach (bidew_data()['singles'] as [$y, $t, $d, $cv]) printf('<li class="reveal">%s<div><b>%s</b><strong>%s</strong><br><span class="entry-sm">%s</span></div></li>',
        $cv ? '<img class="sc" src="' . esc_url(bidew_img($cv)) . '" alt="Pochette de ' . esc_attr($t) . '" loading="lazy" width="64" height="64">' : '', esc_html($y), esc_html($t), esc_html($d));
    echo '</ol>';
}

/* Plateformes d'écoute, références et chiffres clés */
function bidew_render_platforms($refs = true) {
    $d = bidew_data(); echo '<div class="platforms">';
    foreach ($d['platforms'] as [$n, $u, $s]) printf('<a class="plat reveal" href="%s" target="_blank" rel="noopener" data-ev="Listen: %s"><b>%s</b><small>%s</small><span aria-hidden="true">↗</span></a>', esc_url($u), esc_attr($n), esc_html($n), esc_html($s));
    echo '</div>';
    if ($refs) { echo '<p class="refs"><span>Aussi sur :</span>'; foreach ($d['references'] as [$n, $u]) printf('<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url($u), esc_html($n)); echo '</p>'; }
}
function bidew_render_stats() {
    $d = bidew_data(); echo '<div class="stats">';
    foreach ($d['stats'] as [$v, $l]) printf('<div class="stat reveal"><b>%s</b><span>%s</span></div>', esc_html($v), esc_html($l));
    echo '</div><p class="stat-note">Chiffres relevés le ' . esc_html($d['stats_date']) . ' sur YouTube, Spotify et Deezer.</p>';
}

/* Contenus ajoutés depuis l'administration (Partenaires, Revue de presse, Photos, Concerts) */
function bidew_cpt_posts($type, $args = []) {
    return get_posts(array_merge(['post_type' => $type, 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC'], $args));
}

/* Partenaires */
function bidew_partner_groups() {
    $groups = bidew_data()['partners'];
    foreach (bidew_cpt_posts('partenaire') as $p) {
        $g = get_post_meta($p->ID, 'groupe', true) ?: 'Autres partenaires';
        $item = [get_the_title($p), wp_strip_all_tags($p->post_content), get_post_meta($p->ID, 'since', true), get_post_meta($p->ID, 'url', true)];
        $found = false;
        foreach ($groups as $k => $gr) if ($gr['group'] === $g) { $groups[$k]['items'][] = $item; $found = true; break; }
        if (!$found) $groups[] = ['group' => $g, 'items' => [$item]];
    }
    return $groups;
}
function bidew_render_partners($teaser = false) {
    foreach (bidew_partner_groups() as $g) {
        if ($teaser) { echo '<ul class="p-chips">'; foreach ($g['items'] as $it) printf('<li>%s</li>', esc_html($it[0])); echo '</ul>'; continue; }
        printf('<div class="p-group"><h3>%s</h3><div class="grid">', esc_html($g['group']));
        foreach ($g['items'] as [$name, $desc, $since, $url]) printf('<article class="card reveal"><div class="card-body">%s<h3>%s</h3><p>%s</p>%s</div></article>',
            $since ? '<small>' . esc_html($since) . '</small>' : '', esc_html($name), esc_html($desc), $url ? '<p><a class="more" href="' . esc_url($url) . '" target="_blank" rel="noopener">Site / source →</a></p>' : '');
        echo '</div></div>';
    }
}

/* Revue de presse */
function bidew_press_items() {
    $items = [];
    foreach (bidew_cpt_posts('presse', ['orderby' => 'date', 'order' => 'DESC']) as $p)
        $items[] = [get_post_meta($p->ID, 'date_label', true) ?: get_the_date('j F Y', $p), get_post_meta($p->ID, 'source', true), get_the_title($p), get_post_meta($p->ID, 'url', true)];
    return array_merge($items, bidew_data()['press']);
}
function bidew_render_press() {
    echo '<ul class="press">';
    foreach (bidew_press_items() as [$date, $src, $title, $url]) printf('<li class="reveal"><span class="pd">%s</span><div><b>%s</b><a href="%s" target="_blank" rel="noopener">%s</a></div></li>', esc_html($date), esc_html($src), esc_url($url), esc_html($title));
    echo '</ul>';
}

/* Vidéos */
function bidew_video_facade($yt, $title) {
    if (!$yt) return;
    printf('<button class="yt" type="button" data-yt="%1$s" aria-label="Lire : %2$s"><img src="%3$s" alt="" loading="lazy" width="480" height="360"><span class="play" aria-hidden="true"></span></button>', esc_attr($yt), esc_attr($title), esc_url(bidew_yt_thumb($yt)));
}

function bidew_render_videos($limit = -1) {
    $r = new WP_Query(['post_type' => 'video', 'posts_per_page' => $limit, 'orderby' => 'menu_order', 'order' => 'ASC', 'no_found_rows' => true]); echo '<div class="grid">';
    while ($r->have_posts()) : $r->the_post();
        echo '<div class="reveal"><div class="video">'; bidew_video_facade(bidew_youtube_id(get_post_meta(get_the_ID(), 'url_video', true)), get_the_title()); echo '</div><h3 class="vt">' . esc_html(get_the_title()) . '</h3></div>';
    endwhile; wp_reset_postdata(); echo '</div>';
}

/* Membres et engagements */
function bidew_render_members() {
    printf('<figure class="team-photo reveal"><img src="%s" alt="Le trio vêtu de blanc" loading="lazy"><figcaption>Moctar, Beydi et Ibrahim Sall</figcaption></figure>', esc_url(bidew_img('trio-blanc.jpg')));
    $r = new WP_Query(['post_type' => 'membre', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'no_found_rows' => true]); echo '<div class="grid">';
    while ($r->have_posts()) : $r->the_post(); ?>
      <article class="card reveal"><div class="portrait"><?php has_post_thumbnail() ? the_post_thumbnail('large') : print('Photo à fournir'); ?></div>
        <div class="card-body"><small><?php echo esc_html(get_post_meta(get_the_ID(), 'role', true)); ?></small><h3><?php the_title(); ?></h3><?php echo wp_kses_post(wpautop(get_the_content())); ?></div></article>
    <?php endwhile; wp_reset_postdata(); echo '</div>';
    echo '<p class="note">Un quatrième frère a rejoint les trois frères fondateurs : « aujourd\'hui rejoint par le quatrième frère, unis par la musique et la passion » (description officielle du titre « Original », 2025).</p>';
}

function bidew_render_engagements() {
    $r = new WP_Query(['post_type' => 'engagement', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'no_found_rows' => true]); echo '<div class="grid">';
    while ($r->have_posts()) : $r->the_post();
        $img = get_post_meta(get_the_ID(), 'img', true);
        printf('<div class="card reveal">%s<div class="card-body"><small>Engagement</small><h3>%s</h3>%s</div></div>',
            $img ? '<div class="thumb tall"><img src="' . esc_url(bidew_img($img)) . '" alt="" loading="lazy"></div>' : '', esc_html(get_the_title()), wp_kses_post(wpautop(get_the_content())));
    endwhile; wp_reset_postdata(); echo '</div>';
}

/* Galerie : photos classées par catégorie (data/content.json + fichiers assets/img + photos ajoutées dans l'administration) */
function bidew_gallery_items() {
    $items = bidew_data()['gallery'];
    foreach (bidew_cpt_posts('photo', ['orderby' => 'date', 'order' => 'DESC']) as $p) {
        $full = get_the_post_thumbnail_url($p, 'large'); if (!$full) continue;
        $alt = get_post_meta(get_post_thumbnail_id($p), '_wp_attachment_image_alt', true);
        $items[] = ['cat' => sanitize_key(get_post_meta($p->ID, 'cat', true)) ?: 'autres', 'full' => $full, 'thumb' => get_the_post_thumbnail_url($p, 'medium_large') ?: $full, 'alt' => $alt ?: get_the_title($p), 'caption' => get_the_title($p)];
    }
    return $items;
}
function bidew_render_gallery($teaser = 0) {
    $d = bidew_data(); $items = bidew_gallery_items(); $cats = $d['gallery_cats']; $known = array_column($cats, 0);
    foreach ($items as $i) if (!in_array($i['cat'], $known, true)) { $cats[] = [$i['cat'], ucfirst($i['cat']), '']; $known[] = $i['cat']; }
    if ($teaser) { // sélection variée pour l'accueil
        $pick = ['concert-chant.jpg', 'engagement-hopital-dalal-jamm.jpg', 'trio-blanc.jpg', 'pirogues-peintes.jpg', 'concert-guitare.jpg', 'dakar-rue.jpg'];
        $sel = array_values(array_filter($items, fn($i) => isset($i['file']) && in_array($i['file'], $pick, true)));
        usort($sel, fn($a, $b) => array_search($a['file'], $pick) <=> array_search($b['file'], $pick));
        echo '<div class="g-strip">'; foreach (array_slice($sel, 0, $teaser) as $i) bidew_gallery_item($i); echo '</div>'; return;
    }
    echo '<div class="filters" role="group" aria-label="Filtrer la galerie"><button type="button" class="on" aria-pressed="true" data-f="all">Tout</button>';
    foreach ($cats as [$slug, $label]) printf('<button type="button" aria-pressed="false" data-f="%s">%s</button>', esc_attr($slug), esc_html($label));
    echo '</div>';
    foreach ($cats as $c) {
        $slug = $c[0]; $label = $c[1]; $desc = $c[2] ?? '';
        $in = array_filter($items, fn($i) => $i['cat'] === $slug); if (!$in) continue;
        printf('<section class="g-cat" data-cat="%s"><div class="g-head"><h2>%s</h2><p>%s</p></div><div class="gallery">', esc_attr($slug), esc_html($label), esc_html($desc));
        foreach ($in as $i) bidew_gallery_item($i);
        echo '</div></section>';
    }
}
function bidew_gallery_item($i) {
    $full = $i['full'] ?? bidew_img($i['file']); $thumb = $i['thumb'] ?? bidew_img('t/' . $i['file']);
    $dim = isset($i['file']) ? bidew_img_attrs('t/' . $i['file']) : '';
    printf('<a class="g-item reveal" href="%s" data-caption="%s"><img src="%s" alt="%s" loading="lazy"%s><span>%s</span></a>',
        esc_url($full), esc_attr($i['caption']), esc_url($thumb), esc_attr($i['alt']), $dim, esc_html($i['caption']));
}

/* Contact et newsletter */
function bidew_render_booking() {
    $s = sanitize_key($_GET['booking'] ?? '');
    $msgs = ['ok' => 'Merci, votre message a bien été envoyé.', 'invalid' => 'Merci de remplir correctement tous les champs.', 'error' => 'Une erreur est survenue, veuillez réessayer.'];
    if (isset($msgs[$s])) echo '<p role="status" class="notice">' . esc_html($msgs[$s]) . '</p>'; ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="reveal">
      <input type="hidden" name="action" value="bidew_booking"><?php wp_nonce_field('bidew_booking', 'bidew_booking_nonce'); ?>
      <div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>
      <div class="two"><label>Nom<input name="nom" required autocomplete="name"></label><label>Email<input type="email" name="email" required autocomplete="email"></label></div>
      <label>Type de demande<select name="type"><option>Booking concert</option><option>Collaboration</option><option>Presse</option><option>Autre</option></select></label>
      <label>Message<textarea name="message" rows="6" required></textarea></label>
      <button class="btn primary" type="submit">Envoyer</button>
    </form>
    <?php if ($pk = get_option('bidew_presskit')) printf('<p style="margin-top:30px"><a class="more" href="%s">Télécharger le dossier de presse →</a></p>', esc_url($pk));
}

function bidew_render_newsletter() {
    $n = sanitize_key($_GET['news'] ?? '');
    $nm = ['ok' => 'Merci, inscription enregistrée.', 'invalid' => 'Email invalide ou consentement manquant.', 'error' => 'Erreur, veuillez réessayer.'];
    if (isset($nm[$n])) echo '<p role="status" class="notice">' . esc_html($nm[$n]) . '</p>'; ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="reveal">
      <input type="hidden" name="action" value="bidew_news"><?php wp_nonce_field('bidew_news', 'bidew_news_nonce'); ?>
      <div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>
      <label>Email<input type="email" name="email" required autocomplete="email"></label>
      <label class="check"><input type="checkbox" name="consent" value="1" required style="width:auto"> J'accepte de recevoir les actualités du groupe. Désinscription possible à tout moment.</label>
      <button class="btn primary" type="submit">S'inscrire</button>
    </form>
<?php }

/* Gelongal : collectif frère (clips, album 1 SAMBA) */
function bidew_render_gelongal($part) {
    $g = bidew_data()['gelongal'];
    if ($part === 'stats') {
        echo '<div class="stats">'; foreach ($g['stats'] as [$v, $l]) printf('<div class="stat reveal"><b>%s</b><span>%s</span></div>', esc_html($v), esc_html($l)); echo '</div>';
    } elseif ($part === 'who') {
        echo '<div class="grid">'; foreach ($g['who'] as [$t, $d]) printf('<article class="card reveal"><div class="card-body"><h3>%s</h3><p>%s</p></div></article>', esc_html($t), esc_html($d)); echo '</div>';
        printf('<p class="more-row"><a class="btn" href="%s" target="_blank" rel="noopener">Chaîne YouTube Gelongal</a></p>', esc_url($g['channel']));
    } elseif ($part === 'collab') {
        echo '<ol class="collab">';
        foreach ($g['collab'] as [$date, $title, $yt, $views, $note]) printf('<li class="reveal"><a class="cthumb" href="%s" target="_blank" rel="noopener"><img src="%s" alt="" loading="lazy" width="240" height="180"><span class="play" aria-hidden="true"></span></a><div><span class="pd">%s</span><h3>%s</h3><p class="entry-sm">%s</p><small>%s</small></div></li>',
            esc_url(bidew_watch($yt)), esc_url(bidew_yt_thumb($yt)), esc_html($date), esc_html($title), esc_html($note), esc_html($views));
        echo '</ol><p class="note">' . esc_html($g['label']) . '</p>';
    } elseif ($part === 'tribute') {
        echo '<p class="tribute reveal">' . esc_html($g['tribute']) . '</p>';
    } elseif ($part === 'sources') {
        echo '<ul class="sources-list">'; foreach ($g['sources'] as [$l, $u]) printf('<li><a href="%s" target="_blank" rel="noopener">%s</a></li>', esc_url($u), esc_html($l)); echo '</ul>';
    }
}

/* Concerts à venir (type de contenu « Concerts ») */
function bidew_upcoming_concerts() {
    $out = [];
    foreach (bidew_cpt_posts('concert') as $p) {
        $d = get_post_meta($p->ID, 'date', true); if ($d && $d < date('Y-m-d')) continue;
        $out[] = ['title' => get_the_title($p), 'date' => (string) $d, 'ville' => get_post_meta($p->ID, 'ville', true), 'lieu' => get_post_meta($p->ID, 'lieu', true), 'billet' => get_post_meta($p->ID, 'billet', true)];
    }
    usort($out, fn($a, $b) => strcmp($a['date'], $b['date']));
    return $out;
}
function bidew_render_concerts() {
    $list = bidew_upcoming_concerts();
    if ($list) {
        echo '<ul class="concerts">';
        foreach ($list as $c) printf('<li class="reveal"><span class="cd">%s</span><b>%s</b><span>%s</span>%s</li>', esc_html($c['date'] ? wp_date('j F Y', strtotime($c['date'] . ' 12:00')) : ''), esc_html($c['ville'] ?: $c['title']), esc_html($c['lieu']),
            $c['billet'] ? '<a class="btn" href="' . esc_url($c['billet']) . '" target="_blank" rel="noopener" data-ev="Tickets">Billets</a>' : '<span></span>');
        echo '</ul>'; return;
    }
    printf('<div class="empty reveal"><p><b>Aucune date annoncée pour le moment.</b></p><p>Inscrivez-vous à la newsletter pour être prévenu(e) en premier, ou contactez le groupe pour programmer un concert.</p><div class="more-row"><a class="btn primary" href="#newsletter">S\'inscrire</a><a class="btn" href="%s">Booking</a></div></div>', esc_url(home_url('/contact/')));
}

/* Dossier de presse (EPK) */
function bidew_render_epk($part) {
    $e = bidew_data()['epk'];
    if ($part === 'bio') {
        printf('<div class="grid bios"><article class="card reveal"><div class="card-body"><small>Français</small><p id="bio-fr" class="bio">%s</p><button type="button" class="btn copy" data-copy="bio-fr">Copier le texte</button></div></article><article class="card reveal"><div class="card-body"><small>English</small><p id="bio-en" class="bio" lang="en">%s</p><button type="button" class="btn copy" data-copy="bio-en">Copier le texte</button></div></article></div><p class="note">Texte rédigé à partir de sources publiques (voir la page Histoire) ; à valider par le groupe avant diffusion.</p>', esc_html($e['bio_fr']), esc_html($e['bio_en']));
    } elseif ($part === 'facts') {
        echo '<dl class="facts">'; foreach ($e['facts'] as [$k, $v]) printf('<div class="reveal"><dt>%s</dt><dd>%s</dd></div>', esc_html($k), esc_html($v)); echo '</dl>';
    } elseif ($part === 'photos') {
        echo '<div class="g-strip">'; foreach ($e['photos'] as [$f, $c]) printf('<a class="g-item reveal" href="%s" download data-caption="%s"><img src="%s" alt="%s" loading="lazy"%s><span>%s — télécharger</span></a>', esc_url(bidew_img($f)), esc_attr($c), esc_url(bidew_img('t/' . $f)), esc_attr($c), bidew_img_attrs('t/' . $f), esc_html($c)); echo '</div>';
    }
}
function bidew_render_legal() {
    foreach (bidew_data()['legal'] as [$t, $p]) printf('<article class="reveal"><h2>%s</h2><p>%s</p></article>', esc_html($t), esc_html($p));
}

/* Bandeau newsletter (pied de chaque page) */
function bidew_render_newsband() {
    $n = sanitize_key($_GET['news'] ?? '');
    $nm = ['ok' => 'Merci, inscription enregistrée.', 'invalid' => 'E-mail invalide ou consentement manquant.', 'error' => 'Erreur, veuillez réessayer.']; ?>
    <section class="news-band" id="newsletter">
      <div class="nb-txt"><p class="eyebrow">Newsletter</p><h2>Restez dans le rythme</h2><p>Sorties, clips et dates de concerts, directement dans votre boîte mail.</p></div>
      <form class="nb-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="bidew_news"><?php wp_nonce_field('bidew_news', 'bidew_news_nonce'); ?>
        <div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>
        <label class="sr" for="nl">Votre e-mail</label>
        <div class="nb-row"><input id="nl" type="email" name="email" placeholder="Votre e-mail" required autocomplete="email"><button class="btn primary" type="submit" data-ev="Newsletter">S'inscrire</button></div>
        <label class="check"><input type="checkbox" name="consent" value="1" required> J'accepte de recevoir les actualités du groupe (désinscription à tout moment).</label>
        <?php if (isset($nm[$n])) echo '<p role="status" class="ok">' . esc_html($nm[$n]) . '</p>'; ?>
      </form>
    </section>
<?php }

/* Annonce importante (à la une) : rédigée dans data/content.json → headline */
function bidew_render_headline() {
    $h = bidew_data()['headline'] ?? null; if (!$h) return;
    echo '<section class="sec annonce" id="annonce"><div class="annonce-grid">';
    printf('<a class="poster reveal" href="%s" target="_blank" rel="noopener"><img src="%s" alt="%s"%s loading="lazy"></a>', esc_url(bidew_img($h['img'])), esc_url(bidew_img($h['img'])), esc_attr($h['alt']), bidew_img_attrs($h['img']));
    echo '<div class="reveal"><span class="badge">' . esc_html($h['tag']) . '</span><h2>' . esc_html($h['title']) . '</h2><p class="lead">' . esc_html($h['lead']) . '</p><p class="body">' . esc_html($h['body']) . '</p>';
    echo '<div class="info-tiles">'; foreach ($h['info'] as $t) echo '<div><small>' . esc_html($t[0]) . '</small><b>' . esc_html($t[1]) . '</b></div>'; echo '</div><ul>';
    foreach ($h['programme'] as $p) echo '<li>' . esc_html($p) . '</li>';
    echo '</ul>';
    echo '<div class="countdown" data-iso="' . esc_attr($h['iso']) . '" role="timer" aria-label="Compte à rebours avant l\'événement"><div><b>--</b><small>Jours</small></div><div><b>--</b><small>Heures</small></div><div><b>--</b><small>Min</small></div><div><b>--</b><small>Sec</small></div></div>';
    echo '<p class="when">' . esc_html($h['when']) . '</p><div class="btns">';
    foreach ($h['cta'] as $i => $c) printf('<a class="btn%s" href="%s">%s</a>', $i ? '' : ' primary', esc_url(home_url('/' . $c[1] . '/')), esc_html($c[0]));
    echo '</div></div></div></section>';
}

/* Bandeau défilant */
function bidew_render_ticker() {
    $w = ['Bideew Bou Bess', 'Depuis 1994', 'Hip-hop sénégalais', 'De Podor au monde', '1 SAMBA disponible', 'Gelongal × Bideew Bou Bess']; $s = '';
    foreach (array_merge($w, $w) as $x) $s .= '<span>' . esc_html($x) . '</span>';
    echo '<div class="ticker" aria-hidden="true"><div>' . $s . '</div></div>';
}