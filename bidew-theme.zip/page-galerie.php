<?php get_header();
bidew_page_hero('galerie', 'Galerie', 'photos', 'Concerts, engagements, portraits et Sénégal en images : touchez une photo pour l\'agrandir.'); ?>
<section class="sec"><?php bidew_render_gallery(); ?></section>
<?php bidew_cta('Une photo, une interview, un concert ?', 'Contacter le groupe', home_url('/contact/'));
get_footer();